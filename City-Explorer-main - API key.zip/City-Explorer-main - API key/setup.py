#!/usr/bin/env python3
"""
TourGuide Setup Script

This script sets up the TourGuide application structure and installs required dependencies.
"""

import os
import sys
import subprocess
import shutil
import json
from pathlib import Path

# Define colors for terminal output
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def print_status(message, color=Colors.BLUE):
    """Print status message with color"""
    print(f"{color}[TourGuide]{Colors.ENDC} {message}")

def print_error(message):
    """Print error message"""
    print(f"{Colors.FAIL}[ERROR]{Colors.ENDC} {message}")

def print_success(message):
    """Print success message"""
    print(f"{Colors.GREEN}[SUCCESS]{Colors.ENDC} {message}")

def run_command(command, cwd=None):
    """Run shell command and return result"""
    try:
        result = subprocess.run(
            command, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True, 
            shell=True,
            cwd=cwd
        )
        if result.returncode != 0:
            print_error(f"Command failed: {command}")
            print(result.stderr)
            return False
        return True
    except Exception as e:
        print_error(f"Failed to execute command: {e}")
        return False

def check_requirements():
    """Check if all requirements are met"""
    print_status("Checking requirements...")
    
    # Check Python version
    python_version = sys.version_info
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 7):
        print_error("Python 3.7 or higher is required")
        return False
    
    # Check pip installation
    if not run_command("pip --version"):
        print_error("pip is not installed")
        return False
    
    # Check if virtual environment module is available
    try:
        import venv
    except ImportError:
        print_error("venv module is not available")
        return False
    
    print_success("All requirements are met")
    return True

def create_directory_structure():
    """Create the project directory structure"""
    print_status("Creating directory structure...")
    
    # Define project structure
    directories = [
        "tourguide",
        "tourguide/modules",
        "tourguide/static/css",
        "tourguide/static/js",
        "tourguide/static/img",
        "tourguide/static/cache",
        "tourguide/templates",
        "tourguide/templates/partials",
        "tourguide/config"
    ]
    
    # Create directories
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print_status(f"Created directory: {directory}")
    
    # Create placeholder files
    placeholder_files = [
        "tourguide/modules/__init__.py",
        "tourguide/static/cache/.gitkeep",
        "tourguide/config/.env.example"
    ]
    
    for file_path in placeholder_files:
        with open(file_path, 'w') as f:
            pass
        print_status(f"Created file: {file_path}")
    
    print_success("Directory structure created successfully")
    return True

def copy_existing_files():
    """Copy existing files to the new structure"""
    print_status("Copying existing files to the new structure...")
    
    # Define file mappings from original to new location
    file_mappings = [
        ("API-Tourist-Sites.py", "tourguide/modules/API_Tourist_Sites.py"),
        ("scraping.py", "tourguide/modules/scraping.py"),
        ("app.py", "tourguide/app.py")
    ]
    
    # Copy files
    for source, destination in file_mappings:
        if os.path.exists(source):
            shutil.copy2(source, destination)
            print_status(f"Copied {source} to {destination}")
        else:
            print_error(f"Source file not found: {source}")
    
    print_success("Files copied successfully")
    return True

def create_env_file():
    """Create .env file"""
    print_status("Creating .env file...")
    
    env_content = """# TourGuide Environment Variables
GROQ_API_KEY=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
FLASK_APP=app.py
FLASK_ENV=development
SECRET_KEY=tourguide_secret_key_change_this_in_production
"""
    
    with open("tourguide/config/.env", "w") as f:
        f.write(env_content)
    
    # Also create .env.example
    with open("tourguide/config/.env.example", "w") as f:
        f.write(env_content.replace("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", "your_api_key_here"))
    
    print_success(".env file created successfully")
    return True

def setup_virtual_environment():
    """Set up virtual environment"""
    print_status("Setting up virtual environment...")
    
    # Create virtual environment
    if not run_command("python -m venv tourguide/venv"):
        print_error("Failed to create virtual environment")
        return False
    
    # Determine activation script based on platform
    if sys.platform == 'win32':
        activate_script = "tourguide\\venv\\Scripts\\activate"
    else:
        activate_script = "tourguide/venv/bin/activate"
    
    print_success("Virtual environment created successfully")
    return activate_script

def install_dependencies(activate_script):
    """Install required dependencies"""
    print_status("Installing dependencies...")
    
    # Create requirements.txt
    requirements = """
flask==2.2.3
flask-socketio==5.3.3
python-dotenv==1.0.0
geopy==2.3.0
requests==2.28.2
selenium==4.8.2
webdriver-manager==3.8.5
fake-useragent==1.1.1
tabulate==0.9.0
eventlet==0.33.3
"""
    
    with open("tourguide/requirements.txt", "w") as f:
        f.write(requirements)
    
    # Install dependencies
    if sys.platform == 'win32':
        install_cmd = f"call {activate_script} && pip install -r tourguide/requirements.txt"
    else:
        install_cmd = f"source {activate_script} && pip install -r tourguide/requirements.txt"
    
    if not run_command(install_cmd):
        print_error("Failed to install dependencies")
        return False
    
    print_success("Dependencies installed successfully")
    return True

def create_readme():
    """Create README.md file"""
    print_status("Creating README.md file...")
    
    readme_content = """# TourGuide

A Flask-based application for planning optimized tourist itineraries using AI recommendations.

## Features

- AI-powered tourist site recommendations
- Route optimization between sites
- Real-time transport options
- Interactive map visualization
- Multi-language support (French, English, Romanian)

## Installation

1. Ensure you have Python 3.7+ installed
2. Clone this repository
3. Navigate to the project directory
4. Activate the virtual environment:
   ```
   # On Windows
   venv\\Scripts\\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```
5. Install dependencies: `pip install -r requirements.txt`
6. Configure your environment variables in `config/.env`
7. Run the application: `python app.py`
8. Open your browser and navigate to `http://localhost:5000`

## Project Structure

```
tourguide/
│
├── app.py                      # Main Flask application
│
├── modules/                    # Core functionality modules
│   ├── __init__.py             
│   ├── API_Tourist_Sites.py    # Tourist site retrieval API
│   └── scraping.py             # Rome2Rio scraping module
│
├── static/                     # Static assets
│   ├── css/
│   ├── js/
│   ├── img/
│   └── cache/                  # Local file cache
│
├── templates/                  # HTML templates
│   ├── index.html              # Homepage
│   ├── sites.html              # Tourist sites selection page
│   ├── itineraire.html         # Optimized itinerary page
│   └── partials/               # Reusable template parts
│
└── config/                     # Configuration files
    └── .env                    # Environment variables
```

## License

This project is licensed under the MIT License.
"""
    
    with open("tourguide/README.md", "w") as f:
        f.write(readme_content)
    
    print_success("README.md created successfully")
    return True

def create_run_script():
    """Create run script"""
    print_status("Creating run script...")
    
    if sys.platform == 'win32':
        # Windows batch script
        run_script = """@echo off
cd %~dp0
call venv\\Scripts\\activate
python app.py
"""
        script_name = "tourguide/run.bat"
    else:
        # Unix shell script
        run_script = """#!/bin/bash
cd "$(dirname "$0")"
source venv/bin/activate
python app.py
"""
        script_name = "tourguide/run.sh"
    
    with open(script_name, "w") as f:
        f.write(run_script)
    
    # Make the script executable on Unix systems
    if sys.platform != 'win32':
        os.chmod(script_name, 0o755)
    
    print_success(f"Run script created: {script_name}")
    return True

def complete_setup():
    """Complete the setup with final instructions"""
    print_status("Setup completed successfully!", color=Colors.GREEN)
    print("\n" + "="*60)
    print(f"{Colors.BOLD}TourGuide Installation Complete{Colors.ENDC}")
    print("="*60)
    
    if sys.platform == 'win32':
        activate_cmd = "tourguide\\venv\\Scripts\\activate"
        run_cmd = "tourguide\\run.bat"
    else:
        activate_cmd = "source tourguide/venv/bin/activate"
        run_cmd = "./tourguide/run.sh"
    
    print(f"\nTo start the application:")
    print(f"1. Navigate to the project directory")
    print(f"2. Activate the virtual environment:")
    print(f"   {activate_cmd}")
    print(f"3. Run the application:")
    print(f"   python tourguide/app.py")
    print(f"\nOr simply run the provided script:")
    print(f"   {run_cmd}")
    print(f"\nThen open your browser and go to: http://localhost:5000")
    print("\n" + "="*60)
    
    return True

def main():
    """Main function to run the setup"""
    print("\n" + "="*60)
    print(f"{Colors.BOLD}TourGuide Setup{Colors.ENDC}")
    print("="*60 + "\n")
    
    # Check requirements
    if not check_requirements():
        return False
    
    # Create directory structure
    if not create_directory_structure():
        return False
    
    # Copy existing files
    if not copy_existing_files():
        return False
    
    # Create .env file
    if not create_env_file():
        return False
    
    # Set up virtual environment
    activate_script = setup_virtual_environment()
    if not activate_script:
        return False
    
    # Install dependencies
    if not install_dependencies(activate_script):
        return False
    
    # Create README
    if not create_readme():
        return False
    
    # Create run script
    if not create_run_script():
        return False
    
    # Complete setup
    return complete_setup()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print_error("\nSetup interrupted by user")
    except Exception as e:
        print_error(f"Setup failed: {e}")